import React, { useEffect, useState } from 'react';
import CelebrationView from './components/CelebrationView';
import Customizer from './components/Customizer';
import LZString from 'lz-string';
import { db } from './lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { Sparkles } from 'lucide-react';

export default function App() {
  const [wishData, setWishData] = useState<any>(null);
  const [isPreview, setIsPreview] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentWishId, setCurrentWishId] = useState<string | null>(null);

  useEffect(() => {
    const fetchWish = async () => {
      setIsLoading(true);
      const params = new URLSearchParams(window.location.search);
      const id = params.get('id');
      const code = params.get('c');
      const compressedData = params.get('w');

      if (id || code) {
        try {
          const docId = code || id || '';
          const docRef = doc(db, 'wishes', docId);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setWishData(docSnap.data());
            setCurrentWishId(docId);
            setIsPreview(true);
          } else {
            console.error("No such wish found in database");
          }
        } catch (error) {
          console.error("Failed to fetch wish from Firestore:", error);
        }
      } else if (compressedData) {
        try {
          const decompressed = LZString.decompressFromEncodedURIComponent(compressedData);
          if (decompressed) {
            const raw = JSON.parse(decompressed);
            // Map short keys back to full names
            const data = {
              recipient: raw.r,
              occasion: raw.o,
              message: raw.m,
              theme: raw.t,
              musicUrl: raw.mu,
              photo: raw.p,
              photoTheme: raw.pt,
              messageTheme: raw.mt,
              customBg: raw.cb
            };
            setWishData(data);
            setIsPreview(true);
          }
        } catch (error) {
          console.error("Failed to decompress wish data:", error);
        }
      } else {
        // Legacy support mapping preserved if needed, but compressed is preferred
      }
      setIsLoading(false);
    };

    fetchWish();
  }, []);

  const handlePreview = (data: any) => {
    setWishData(data);
    setIsPreview(true);
    if (data.wishId) {
      setCurrentWishId(data.wishId);
    }
    
    // Create compressed payload with short keys for URL (legacy fallback)
    const compactData: any = {
      r: data.recipient,
      o: data.occasion,
      m: data.message,
      t: data.theme
    };
    if (data.musicUrl) compactData.mu = data.musicUrl;
    if (data.photo) compactData.p = data.photo;
    if (data.photoTheme && data.photoTheme !== 'gold') compactData.pt = data.photoTheme;
    if (data.messageTheme && data.messageTheme !== 'modern') compactData.mt = data.messageTheme;
    if (data.customBg) compactData.cb = data.customBg;

    const payload = JSON.stringify(compactData);
    const compressed = LZString.compressToEncodedURIComponent(payload);
    
    const params = new URLSearchParams();
    params.set('w', compressed);
    
    const newUrl = `${window.location.origin}${window.location.pathname}?${params.toString()}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
  };

  const handleBack = () => {
    setIsPreview(false);
    // Clear URL params
    window.history.pushState({}, '', window.location.pathname);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FAF8F6] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Sparkles className="w-8 h-8 text-gold animate-pulse" />
          <p className="text-navy/40 font-serif italic text-lg tracking-widest uppercase">Loading your wish...</p>
        </div>
      </div>
    );
  }

  if (isPreview && wishData) {
    return (
      <div className="relative">
        <CelebrationView {...wishData} wishId={currentWishId} />
        <button 
          onClick={handleBack}
          className="fixed top-4 left-4 z-50 px-4 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-full text-white text-sm transition-all"
        >
          ← Edit Wish
        </button>
      </div>
    );
  }

  return <Customizer onPreview={handlePreview} />;
}

import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import { Music, Music2, Volume2, VolumeX, Share2, Heart, Star, Cake, Gift, Play, Pause, Copy, Check, GraduationCap, Home, Trophy, Plane, Flower2, Baby, Stethoscope, Palmtree, HeartHandshake, Snowflake, Ghost, Gem, Map as MapIcon, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import LZString from 'lz-string';

interface CelebrationViewProps {
  recipient: string;
  occasion: string;
  message: string;
  theme: 'birthday' | 'anniversary' | 'congratulations' | 'general' | 'wedding' | 'graduation' | 'farewell' | 'new_home' | 'promotion' | 'new_baby' | 'get_well' | 'retirement' | 'thank_you' | 'holiday' | 'halloween' | 'engagement' | 'travel';
  musicUrl?: string;
  photo?: string;
  photoTheme?: keyof typeof PHOTO_THEMES;
  messageTheme?: keyof typeof MESSAGE_THEMES;
  customBg?: string;
  wishId?: string | null;
}

const PHOTO_THEMES = {
  polaroid: "bg-white p-2 shadow-2xl",
  modern: "bg-navy p-1 shadow-xl rounded-lg",
  glass: "bg-white/20 backdrop-blur-md border border-white/30 p-2 shadow-lg",
  gold: "bg-[#D4AF37] p-2 shadow-[0_0_20px_rgba(212,175,55,0.4)]",
};

const MESSAGE_THEMES = {
  classic: "bg-[#FDFCFB] border border-[#E5E2DE] shadow-sm",
  modern: "bg-[#1A2A3A] text-white border border-white/10 shadow-xl",
  glass: "bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl text-white",
  stellar: "bg-navy border border-gold/30 shadow-[0_0_30px_rgba(212,175,55,0.15)] text-white relative overflow-hidden",
};

interface ThemeConfig {
  accent: string;
  icon: any;
  particles: string[];
  specialSlides?: Array<{
    bg: string;
    content: 'message' | 'photo';
  }>;
}

const THEMES: Record<string, ThemeConfig> = {
  birthday: {
    accent: '#D4AF37',
    icon: Cake,
    particles: ['🎂', '🎈', '✨', '🎁'],
    specialSlides: [
      {
        bg: "https://images.unsplash.com/photo-1464347744102-11db6282f854?auto=format&fit=crop&q=80&w=2070", // Dark festive/stellar
        content: 'message'
      },
      {
        bg: "https://images.unsplash.com/photo-1549416878-b9ca35329960?auto=format&fit=crop&q=80&w=2070", // Purple balloon frame vibe
        content: 'photo'
      }
    ]
  },
  anniversary: {
    accent: '#C66B44',
    icon: Heart,
    particles: ['❤️', '💖', '✨', '🌹'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  wedding: {
    accent: '#D4AF37',
    icon: Flower2,
    particles: ['💍', '🥂', '💖', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  graduation: {
    accent: '#1A2B3C',
    icon: GraduationCap,
    particles: ['🎓', '📜', '✨', '🎉'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  farewell: {
    accent: '#C66B44',
    icon: Plane,
    particles: ['🛫', '👋', '🌍', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  new_home: {
    accent: '#D4AF37',
    icon: Home,
    particles: ['🏠', '🔑', '🏡', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  promotion: {
    accent: '#D4AF37',
    icon: Trophy,
    particles: ['🏆', '📈', '🚀', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  new_baby: {
    accent: '#f472b6',
    icon: Baby,
    particles: ['🍼', '🧸', '👶', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  retirement: {
    accent: '#f59e0b',
    icon: Palmtree,
    particles: ['🌴', '☀️', '🍹', '🌊'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  travel: {
    accent: '#3b82f6',
    icon: MapIcon,
    particles: ['🌍', '✈️', '🗺️', '🏝️'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  thank_you: {
    accent: '#8b5cf6',
    icon: HeartHandshake,
    particles: ['🙏', '💖', '🌸', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  get_well: {
    accent: '#10b981',
    icon: Stethoscope,
    particles: ['❤️', '🍵', '☀️', '🌸'],
    specialSlides: [
      {
        bg: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=2070",
        content: 'message'
      }
    ]
  },
  holiday: {
    accent: '#ef4444',
    icon: Snowflake,
    particles: ['❄️', '🎄', '🎁', '✨'],
    specialSlides: [
      {
        bg: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
        content: 'message'
      }
    ]
  },
  halloween: {
    accent: '#f97316',
    icon: Ghost,
    particles: ['👻', '🎃', '🦇', '🍬'],
    specialSlides: [
      {
        bg: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=2070",
        content: 'message'
      }
    ]
  },
  engagement: {
    accent: '#14b8a6',
    icon: Gem,
    particles: ['💍', '🥂', '💖', '✨'],
    specialSlides: [
      {
        bg: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&q=80&w=2070",
        content: 'message'
      }
    ]
  },
  general: {
    accent: '#D4AF37',
    icon: Star,
    particles: ['✨', '💫', '🌟', '✨'],
    specialSlides: [
      {
        bg: "https://images.unsplash.com/photo-1464347744102-11db6282f854?auto=format&fit=crop&q=80&w=2070",
        content: 'message'
      }
    ]
  },
};

export default function CelebrationView({ 
  recipient, 
  occasion, 
  message, 
  theme, 
  musicUrl, 
  photo,
  photoTheme = 'gold',
  messageTheme = 'modern',
  customBg,
  wishId
}: CelebrationViewProps) {
  const [isMuted, setIsMuted] = useState(true);
  const [volume, setVolume] = useState(0.5);
  const [hasStarted, setHasStarted] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [copied, setCopied] = useState(false);
  const [photoError, setPhotoError] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentTheme = THEMES[theme] || THEMES.general;

  // Reset error state if photo changes
  useEffect(() => {
    setPhotoError(false);
  }, [photo]);

  // Dynamically compute slides based on theme and uploaded photo
  const slides = React.useMemo(() => {
    let baseSlides = currentTheme.specialSlides ? [...currentTheme.specialSlides] : [
      {
        bg: customBg || (THEMES[theme] || THEMES.birthday).specialSlides?.[0]?.bg || "https://images.unsplash.com/photo-1464347744102-11db6282f854?auto=format&fit=crop&q=80&w=2070",
        content: 'message' as const
      }
    ];

    // If an external photo was uploaded and it's not already represented in specialSlides, add it
    if (photo && !baseSlides.some(s => s.content === 'photo')) {
      baseSlides.push({
        bg: customBg || baseSlides[0].bg,
        content: 'photo' as const
      });
    }
    return baseSlides;
  }, [currentTheme, photo, theme, customBg]);

  useEffect(() => {
    let interval: any;
    if (hasStarted && slides.length > 1) {
      interval = setInterval(() => {
        setCurrentSlide(prev => (prev + 1) % slides.length);
      }, 5000); // 5 seconds per slide
    }
    return () => clearInterval(interval);
  }, [hasStarted, slides]);

  useEffect(() => {
    if (hasStarted && audioRef.current) {
      audioRef.current.volume = volume;
      if (!isMuted) {
        audioRef.current.play().catch(e => console.error("Audio play failed:", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [isMuted, hasStarted, volume]);

  const handleStart = () => {
    setHasStarted(true);
    setIsMuted(false);
    triggerConfetti();
  };

  const triggerConfetti = () => {
    const duration = 5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    const randomInRange = (min: number, max: number) => Math.random() * (max - min) + min;

    const interval: any = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 } });
      confetti({ ...defaults, particleCount, origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 } });
    }, 250);
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-[#FAF8F6] text-[#1A2B3C] flex items-center justify-center p-4 md:p-8">
      {/* Geometric Background Elements */}
      <div className="absolute top-[-100px] right-[-100px] w-[600px] h-[600px] rounded-full border border-gold/20 pointer-events-none" />
      <div className="absolute bottom-[-50px] left-[-100px] w-[400px] h-[400px] rounded-full border border-terracotta/15 pointer-events-none" />
      <div className="absolute top-[20%] left-0 w-[150px] h-[1px] bg-gold pointer-events-none" />
      <div className="absolute bottom-[20%] right-0 w-[150px] h-[1px] bg-gold pointer-events-none" />

      {/* Floating Particles */}
      <div className="absolute inset-0 pointer-events-none z-20">
        {hasStarted && Array.from({ length: 15 }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000), 
              y: (typeof window !== 'undefined' ? window.innerHeight : 1000) + 100,
              opacity: 0,
              scale: Math.random() * 0.5 + 0.5
            }}
            animate={{ 
              y: -100,
              opacity: [0, 1, 1, 0],
              rotate: 360
            }}
            transition={{ 
              duration: Math.random() * 10 + 10,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "linear"
            }}
            className="absolute text-2xl"
          >
            {currentTheme.particles[i % currentTheme.particles.length]}
          </motion.div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {!hasStarted ? (
          <motion.div
            key="start"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="z-10 text-center space-y-12 max-w-lg"
          >
            <div className="space-y-6">
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="inline-block p-6 rounded-full bg-white shadow-xl border border-soft-grey"
              >
                <Gift className="w-12 h-12 text-gold" />
              </motion.div>
              <div className="space-y-4">
                <h2 className="text-xs uppercase tracking-[0.4em] text-navy/40 font-bold">{occasion}</h2>
                <h1 className="text-5xl md:text-7xl font-serif italic tracking-tighter text-navy">For {recipient}</h1>
              </div>
            </div>
            <Button 
              onClick={handleStart}
              size="lg"
              className="rounded-none px-16 py-10 text-xl bg-navy text-white hover:bg-navy/90 transition-all hover:translate-y-[-4px] shadow-2xl"
            >
              Open Your Wish
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="z-10 w-full max-w-6xl bg-white shadow-[0_40px_100px_rgba(0,0,0,0.08)] rounded-sm overflow-hidden grid grid-cols-1 md:grid-cols-[450px_1fr]"
          >
            {/* Image/Icon Side */}
            <div className="bg-navy flex flex-col items-center justify-center relative min-h-[400px] md:min-h-[600px] overflow-hidden">
              {/* Custom or Theme Background */}
              {(customBg || slides[currentSlide]?.bg) && (
                <div className="absolute inset-0 z-0">
                  <div className="absolute inset-0 bg-black/40 z-10" />
                  <img 
                    src={customBg || slides[currentSlide]?.bg} 
                    alt="Background" 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className="absolute inset-x-0 top-12 z-30 px-8 text-center pointer-events-none">
                {/* Persistent Occasion Overlay - Now at the top */}
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 1 }}
                >
                  <h2 className="text-white font-serif text-xl md:text-3xl uppercase tracking-[0.3em] drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)] text-balance leading-tight">
                    {occasion}
                  </h2>
                  <div className="w-12 h-0.5 bg-gold mx-auto mt-4 shadow-[0_0_10px_rgba(212,175,55,0.8)]" />
                </motion.div>
              </div>

              <div className="absolute inset-0 z-20 flex items-center justify-center p-8">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentSlide}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.5 }}
                    className="w-full h-full flex items-center justify-center"
                  >
                    {slides[currentSlide].content === 'message' ? (
                      <div className="flex flex-col items-center justify-center text-center">
                        <motion.div
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="bg-white/10 backdrop-blur-md border border-white/20 p-8 rounded-sm"
                        >
                          <Gift className="w-16 h-16 text-gold mb-6 mx-auto animate-bounce" />
                          <div className="text-white font-serif text-2xl md:text-4xl italic tracking-widest uppercase">
                            A Special Wish
                          </div>
                        </motion.div>
                      </div>
                    ) : (
                      <div className="relative">
                        {photo && !photoError ? (
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className={`w-full max-w-[363px] h-auto aspect-[363/588] max-h-[588px] ${PHOTO_THEMES[photoTheme] || PHOTO_THEMES.polaroid}`}
                          >
                            {photo.startsWith('data:application/pdf') ? (
                              <embed src={photo} className="w-full h-full" type="application/pdf" />
                            ) : (
                              <img 
                                src={photo} 
                                alt="Celebration" 
                                className="w-full h-full object-cover" 
                                onError={() => setPhotoError(true)}
                              />
                            )}
                          </motion.div>
                        ) : (
                          <div className="flex flex-col items-center gap-4">
                            <currentTheme.icon className="w-32 h-32 text-white/40" />
                            {photoError && (
                              <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">
                                Image could not be loaded
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="absolute bottom-10 right-10 font-serif text-2xl text-white/30">
                {new Date().toLocaleDateString('en-GB').replace(/\//g, '.')}
              </div>
            </div>

            {/* Content Side */}
            <div className="p-8 md:p-16 flex flex-col justify-between space-y-12">
              <div className="space-y-8">
                <motion.h1 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-5xl md:text-7xl font-serif leading-[1.1] text-navy"
                >
                  {occasion}
                </motion.h1>
                
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className={`p-8 md:p-12 min-h-[150px] flex items-center relative ${MESSAGE_THEMES[messageTheme] || MESSAGE_THEMES.classic}`}
                >
                  {messageTheme === 'stellar' && (
                    <>
                      <div className="absolute inset-0 opacity-10 pointer-events-none">
                        <div className="absolute top-4 left-4 text-xl">🎈</div>
                        <div className="absolute bottom-4 right-4 text-xl">🎈</div>
                        <div className="absolute top-1/2 right-10 text-xs text-gold">✨</div>
                        <div className="absolute top-10 right-4 text-xs text-gold">⭐</div>
                      </div>
                    </>
                  )}
                  <p className="text-xl md:text-2xl leading-relaxed font-sans italic opacity-80 whitespace-pre-wrap z-10">
                    "{message}"
                  </p>
                </motion.div>
              </div>

              <div className="space-y-8">
                  {/* Existing Music Player UI */}
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.3 }}
                    className="bg-warm-bg p-6 rounded-lg flex flex-col gap-4"
                >
                  <div className="flex items-center gap-6">
                    <button 
                      onClick={() => setIsMuted(!isMuted)}
                      className="w-12 h-12 rounded-full bg-navy flex items-center justify-center text-white transition-transform hover:scale-105 active:scale-95 shrink-0"
                    >
                      {isMuted ? <Play className="w-5 h-5 ml-1" /> : <Pause className="w-5 h-5" />}
                    </button>
                    
                    <div className="flex-grow space-y-2">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-navy/60">
                        Background Melody
                      </div>
                      <div className="flex items-end gap-[3px] h-4">
                        {Array.from({ length: 24 }).map((_, i) => (
                          <motion.div
                            key={i}
                            animate={!isMuted ? { 
                              height: [8, 15, 10, 14, 8],
                            } : { height: 8 }}
                            transition={{ 
                              duration: 1.5, 
                              repeat: Infinity, 
                              delay: i * 0.05,
                              ease: "easeInOut"
                            }}
                            className="w-[3px] bg-gold rounded-full"
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Volume Control */}
                  <div className="flex items-center gap-3 px-2 pt-2 border-t border-navy/5">
                    <button 
                      onClick={() => setIsMuted(!isMuted)}
                      className="text-navy/40 hover:text-navy transition-colors"
                    >
                      {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                    <input 
                      type="range"
                      min="0"
                      max="1"
                      step="0.01"
                      value={isMuted ? 0 : volume}
                      onChange={(e) => {
                        const newVol = parseFloat(e.target.value);
                        setVolume(newVol);
                        if (newVol > 0 && isMuted) {
                          setIsMuted(false);
                        }
                      }}
                      className="flex-grow h-1 bg-navy/10 rounded-full appearance-none cursor-pointer accent-gold"
                    />
                    <span className="text-[10px] font-bold text-navy/40 w-8 text-right font-mono">
                      {Math.round((isMuted ? 0 : volume) * 100)}%
                    </span>
                  </div>
                </motion.div>

                <div className="flex items-center justify-between pt-8 border-t border-soft-grey">
                  <div className="flex gap-8">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-terracotta font-bold mb-1">Sent By</div>
                      <div className="font-bold text-sm">A Friend</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-terracotta font-bold mb-1">Moment</div>
                      <div className="font-bold text-sm">Today</div>
                    </div>
                  </div>
                  
                  <Dialog>
                    <DialogTrigger 
                      render={
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-navy/60 hover:text-navy gap-2"
                        >
                          <Share2 className="w-4 h-4" />
                          Share
                        </Button>
                      }
                    />
                    <DialogContent className="sm:max-w-md bg-white rounded-none border-navy/10">
                      <DialogHeader>
                        <DialogTitle className="font-serif italic text-2xl text-navy">Share this wish</DialogTitle>
                        <DialogDescription className="text-navy/50">
                          Copy the link below to send this personalized wish to someone special.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="flex items-center space-x-2 pt-4">
                        <div className="grid flex-1 gap-2">
                          <textarea
                            id="link"
                            rows={5}
                            defaultValue={(() => {
                              const data = { r: recipient, o: occasion, m: message, t: theme, mu: musicUrl, p: photo, pt: photoTheme, mt: messageTheme, cb: customBg };
                              const payload = JSON.stringify(data);
                              const compressed = LZString.compressToEncodedURIComponent(payload);
                              return `${window.location.origin}${window.location.pathname}?w=${compressed}`;
                            })()}
                            readOnly
                            className="w-full bg-warm-bg border border-soft-grey rounded-none focus:ring-gold p-2 text-[10px] font-mono resize-none focus-visible:outline-none"
                          />
                        </div>
                        <Button 
                          type="submit" 
                          size="sm" 
                          className="px-3 bg-navy text-white rounded-none hover:bg-navy/90"
                          onClick={() => {
                            const data = { r: recipient, o: occasion, m: message, t: theme, mu: musicUrl, p: photo, pt: photoTheme, mt: messageTheme, cb: customBg };
                            const payload = JSON.stringify(data);
                            const compressed = LZString.compressToEncodedURIComponent(payload);
                            const finalUrl = `${window.location.origin}${window.location.pathname}?w=${compressed}`;
                            navigator.clipboard.writeText(finalUrl);
                            setCopied(true);
                            setTimeout(() => setCopied(false), 2000);
                          }}
                        >
                          <span className="sr-only">Copy</span>
                          {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Fixed Bottom Share Bar */}
      {hasStarted && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-xl border-t border-white/20 p-2 md:p-3 flex items-center justify-center gap-2 md:gap-4 flex-wrap"
        >
          <div className="flex items-center gap-2 text-white/60 text-[10px] font-bold uppercase tracking-widest hidden sm:flex">
            <Share2 className="w-3 h-3" />
            <span>Shareable Link:</span>
          </div>
          <div className="flex bg-white/5 border border-white/10 rounded-sm overflow-hidden flex-1 max-w-xl">
            <input 
              readOnly
              value={(() => {
                if (wishId) {
                  const param = wishId.length <= 10 ? 'c' : 'id';
                  return `${window.location.origin}${window.location.pathname}?${param}=${wishId}`;
                }
                const data: any = { r: recipient, o: occasion, m: message, t: theme };
                if (musicUrl) data.mu = musicUrl;
                if (photo) data.p = photo;
                const payload = JSON.stringify(data);
                const compressed = LZString.compressToEncodedURIComponent(payload);
                return `${window.location.origin}${window.location.pathname}?w=${compressed}`;
              })()}
              className="bg-transparent text-white/80 text-[10px] font-mono px-3 py-2 flex-1 focus:outline-none"
              onClick={(e) => (e.target as HTMLInputElement).select()}
            />
            <Button
              size="sm"
              variant="ghost"
              className="px-4 py-0 h-auto text-white/60 hover:text-white hover:bg-white/10 rounded-none border-l border-white/10"
              onClick={() => {
                const url = (() => {
                  if (wishId) {
                    const param = wishId.length <= 10 ? 'c' : 'id';
                    return `${window.location.origin}${window.location.pathname}?${param}=${wishId}`;
                  }
                  const data: any = { r: recipient, o: occasion, m: message, t: theme };
                  if (musicUrl) data.mu = musicUrl;
                  if (photo) data.p = photo;
                  const payload = JSON.stringify(data);
                  const compressed = LZString.compressToEncodedURIComponent(payload);
                  return `${window.location.origin}${window.location.pathname}?w=${compressed}`;
                })();
                navigator.clipboard.writeText(url);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
            >
              {copied ? <Check className="w-3 h-3 mr-2" /> : <Copy className="w-3 h-3 mr-2" />}
              <span className="text-[10px] font-bold uppercase tracking-widest">{copied ? 'Copied' : 'Copy'}</span>
            </Button>
          </div>
        </motion.div>
      )}

      {musicUrl && (
        <audio
          ref={audioRef}
          src={musicUrl}
          loop
          preload="auto"
        />
      )}
    </div>
  );
}

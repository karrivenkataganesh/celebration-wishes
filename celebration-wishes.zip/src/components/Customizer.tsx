import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Cake, Heart, Star, Gift, Music, Sparkles, Copy, GraduationCap, Plane, Home, Trophy, Flower2, Upload, FileText, X, Baby, Stethoscope, ImageIcon, Frame, Sparkle, Layout, Palmtree, HeartHandshake, Snowflake, Ghost, Gem, Map as MapIcon, Camera } from 'lucide-react';

import LZString from 'lz-string';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, addDoc, setDoc, doc, getDoc, serverTimestamp } from 'firebase/firestore';
import { Loader2, Save, Key, Search } from 'lucide-react';

interface CustomizerProps {
  onPreview: (data: any) => void;
}

const MUSIC_OPTIONS = [
  { label: 'Happy Birthday', value: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
  { label: 'Romantic Anniversary', value: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
  { label: 'Cheerful Celebration', value: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' },
  { label: 'Peaceful Wish', value: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3' },
];

const PHOTO_THEMES = [
  { id: 'polaroid', label: 'Polaroid', icon: ImageIcon },
  { id: 'modern', label: 'Modern', icon: Frame },
  { id: 'glass', label: 'Glass', icon: Sparkle },
  { id: 'gold', label: 'Premium Gold', icon: Layout },
];

const MESSAGE_THEMES = [
  { id: 'classic', label: 'Classic', icon: FileText, styles: "bg-[#FDFCFB] border-[#E5E2DE] text-navy shadow-sm" },
  { id: 'modern', label: 'Modern', icon: Layout, styles: "bg-[#1A2A3A] text-white border-white/10 shadow-xl" },
  { id: 'glass', label: 'Glass', icon: Sparkles, styles: "bg-navy/30 backdrop-blur-md border-white/20 text-white shadow-2xl" },
  { id: 'stellar', label: 'Stellar', icon: Star, styles: "bg-navy border-gold/30 text-white shadow-[0_0_15px_rgba(212,175,55,0.1)]" },
];

const THEME_GIFS: Record<string, string> = {
  birthday: "https://images.unsplash.com/photo-1464347744102-11db6282f854?auto=format&fit=crop&q=80&w=2070",
  anniversary: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  wedding: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  graduation: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  farewell: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  new_home: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  promotion: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  new_baby: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  retirement: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  travel: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  thank_you: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  get_well: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=2070",
  holiday: "https://tse4.mm.bing.net/th/id/OIP.WR8bQKkJ9oAlEM4fz476bgHaHa?w=600&h=600&rs=1&pid=ImgDetMain&o=7&rm=3",
  halloween: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&q=80&w=2070",
  engagement: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&q=80&w=2070",
};

const OCCASION_OPTIONS = [
  { label: 'Select Option', value: '', themeId: 'birthday' },
  { label: 'Birthday', value: 'Happy Birthday', themeId: 'birthday' },
  { label: 'Anniversary', value: 'Happy Anniversary Day', themeId: 'anniversary' },
  { label: 'Wedding', value: 'Happy Wedding Day', themeId: 'wedding' },
  { label: 'Graduation', value: 'Happy Graduation Day', themeId: 'graduation' },
  { label: 'New Baby', value: 'Congratulations on Your New Baby', themeId: 'new_baby' },
  { label: 'Get well', value: 'Sending Healing Wishes', themeId: 'get_well' },
  { label: 'Retirement', value: 'Happy Retirement Day', themeId: 'retirement' },
  { label: 'Thank you', value: 'Heartful Thanks', themeId: 'thank_you' },
  { label: 'Holiday', value: 'Warm Holiday Wishes', themeId: 'holiday' },
  { label: 'Halloween', value: 'Happy Halloween Day', themeId: 'halloween' },
  { label: 'Engagement', value: 'Wishing You a Happy Engagement', themeId: 'engagement' },
  { label: 'Travel', value: 'Happy Journey', themeId: 'travel' },
  { label: 'Promotion', value: 'Cheers to Your Promotion', themeId: 'promotion' },
  { label: 'New Home', value: 'May Your New Home Be Filled with Joy!', themeId: 'new_home' },
  { label: 'Farewell', value: 'Wishing You Success in Your Next Journey!', themeId: 'farewell' },
];

export default function Customizer({ onPreview }: CustomizerProps) {
  const [recipient, setRecipient] = useState('');
  const [occasion, setOccasion] = useState('');
  const [message, setMessage] = useState('');
  const [theme, setTheme] = useState<'birthday' | 'anniversary' | 'wedding' | 'graduation' | 'farewell' | 'new_home' | 'promotion' | 'new_baby' | 'get_well' | 'retirement' | 'thank_you' | 'holiday' | 'halloween' | 'engagement' | 'travel'>('birthday');
  const [musicUrl, setMusicUrl] = useState(MUSIC_OPTIONS[0].value);
  const [photo, setPhoto] = useState('');
  const [photoTheme, setPhotoTheme] = useState('gold');
  const [messageTheme, setMessageTheme] = useState('modern');
  const [customBg, setCustomBg] = useState('');
  const [isUploading, setIsUploading] = useState<{ [key: number]: boolean }>({});
  const [photoError, setPhotoError] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [loadCode, setLoadCode] = useState('');
  const [isLoadingCode, setIsLoadingCode] = useState(false);

  const generateShortCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Avoid ambiguous chars
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  };

  const handleLoadByCode = async () => {
    if (!loadCode || loadCode.length < 3) {
      alert('Please enter a valid code');
      return;
    }

    setIsLoadingCode(true);
    try {
      const cleanCode = loadCode.trim().toUpperCase();
      const docRef = doc(db, 'wishes', cleanCode);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        onPreview({ ...data, wishId: cleanCode });
      } else {
        alert('No wish found with that code. Please check and try again.');
      }
    } catch (error) {
      console.error('Error loading wish:', error);
      alert('Error searching for that code.');
    } finally {
      setIsLoadingCode(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Limit to 1.5MB for URL safety even with compression (total across both should be mindful)
    if (file.size > 1.2 * 1024 * 1024) {
      alert('File is too large. Please select a file under 1.2MB for better compatibility.');
      return;
    }

    setIsUploading(prev => ({ ...prev, [index]: true }));

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (index === 1) {
        setPhoto(result);
        setPhotoError(false);
      }
      else if (index === 3) setCustomBg(result);
      setIsUploading(prev => ({ ...prev, [index]: false }));
    };
    reader.onerror = () => {
      alert('Failed to read file.');
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = () => {
    if (!recipient || !message) {
      alert('Please fill in the recipient and message!');
      return;
    }
    onPreview({ recipient, occasion, message, theme, musicUrl, photo, photoTheme, messageTheme, customBg });
  };

  const handleSaveToDatabase = async () => {
    if (!recipient || !message) {
      alert('Please fill in the recipient and message first!');
      return;
    }

    setIsSaving(true);
    try {
      const wishCode = generateShortCode();
      const wishPayload: any = {
        recipient,
        occasion,
        message,
        theme,
        createdAt: serverTimestamp(),
      };

      if (musicUrl) wishPayload.musicUrl = musicUrl;
      if (photo) wishPayload.photo = photo;
      if (photoTheme && photoTheme !== 'gold') wishPayload.photoTheme = photoTheme;
      if (messageTheme && messageTheme !== 'modern') wishPayload.messageTheme = messageTheme;
      if (customBg) wishPayload.customBg = customBg;

      // Use setDoc with custom code as document ID
      await setDoc(doc(db, 'wishes', wishCode), wishPayload);

      const shareUrl = `${window.location.origin}${window.location.pathname}?c=${wishCode}`;
      await navigator.clipboard.writeText(shareUrl);
      
      // Update preview with the saved code so the share link is correct
      onPreview({ 
        ...wishPayload,
        wishId: wishCode 
      });
      
      alert(`Your wish has been saved! Code: ${wishCode}. The link has been copied to your clipboard.`);
    } catch (error) {
      console.error('Save failed:', error);
      handleFirestoreError(error, OperationType.CREATE, 'wishes');
      alert('Failed to save to database. Please check your connection and try again.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF8F6] flex items-center justify-center p-4 md:p-8 relative overflow-hidden">
      {/* Background Shapes */}
      <div className="absolute top-[-200px] right-[-200px] w-[800px] h-[800px] rounded-full border border-soft-grey pointer-events-none" />
      <div className="absolute bottom-[-100px] left-[-100px] w-[400px] h-[400px] rounded-full border border-soft-grey pointer-events-none" />

      <div className="w-full max-w-2xl space-y-8 relative z-10">
        <div className="text-center space-y-3">
          <h1 className="text-5xl font-serif italic tracking-tight text-navy">Celebration Wishes</h1>
          <p className="text-navy/60 font-medium tracking-wide uppercase text-xs">Create a personalized digital greeting</p>
        </div>

        <Card className="border-none shadow-[0_40px_100px_rgba(0,0,0,0.08)] rounded-sm overflow-hidden">
          <CardHeader className="bg-white border-b border-soft-grey p-8">
            <CardTitle className="flex items-center gap-3 text-navy font-serif italic text-2xl">
              <Sparkles className="w-6 h-6 text-gold" />
              Customize Your Wish
            </CardTitle>
            <CardDescription className="text-navy/50">Fill in the details to generate a unique celebration link.</CardDescription>
          </CardHeader>
          <CardContent className="p-8 space-y-8 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <Label htmlFor="recipient" className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Recipient Name</Label>
                <Input 
                  id="recipient" 
                  placeholder="e.g. Sarah" 
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value)}
                  className="bg-warm-bg border-soft-grey focus:ring-gold rounded-none h-12"
                />
              </div>
              <div className="space-y-3">
                <Label htmlFor="occasion" className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Occasion</Label>
                <Select value={occasion} onValueChange={(val) => {
                  setOccasion(val);
                  const opt = OCCASION_OPTIONS.find(o => o.value === val);
                  if (opt) setTheme(opt.themeId as any);
                }}>
                  <SelectTrigger id="occasion" className="bg-warm-bg border-soft-grey rounded-none h-12">
                    <SelectValue placeholder="Select occasion" />
                  </SelectTrigger>
                  <SelectContent className="backdrop-blur-xl bg-white/90">
                    {OCCASION_OPTIONS.map((opt) => (
                      <SelectItem 
                        key={opt.value} 
                        value={opt.value}
                        className={opt.value === '' ? 'text-navy/40 italic' : ''}
                      >
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Theme Aesthetic</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {[
                  { id: 'birthday', icon: Cake, label: 'Birthday' },
                  { id: 'anniversary', icon: Heart, label: 'Anniversary' },
                  { id: 'wedding', icon: Flower2, label: 'Wedding' },
                  { id: 'graduation', icon: GraduationCap, label: 'Graduation' },
                  { id: 'new_baby', icon: Baby, label: 'New Baby' },
                  { id: 'get_well', icon: Stethoscope, label: 'Get Well' },
                  { id: 'retirement', icon: Palmtree, label: 'Retirement' },
                  { id: 'thank_you', icon: HeartHandshake, label: 'Thank You' },
                  { id: 'holiday', icon: Snowflake, label: 'Holiday' },
                  { id: 'halloween', icon: Ghost, label: 'Halloween' },
                  { id: 'engagement', icon: Gem, label: 'Engagement' },
                  { id: 'travel', icon: MapIcon, label: 'Travel' },
                  { id: 'promotion', icon: Trophy, label: 'Promotion' },
                  { id: 'new_home', icon: Home, label: 'New Home' },
                  { id: 'farewell', icon: Plane, label: 'Farewell' },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      setTheme(t.id as any);
                      const opt = OCCASION_OPTIONS.find(o => o.themeId === t.id);
                      if (opt) setOccasion(opt.value);
                    }}
                    className={`flex flex-col items-center justify-center p-4 rounded-none border-2 transition-all ${
                      theme === t.id 
                        ? 'border-gold bg-warm-bg text-navy' 
                        : 'border-soft-grey bg-white text-navy/30 hover:border-navy/20'
                    }`}
                  >
                    <t.icon className={`w-5 h-5 mb-2 ${theme === t.id ? 'text-gold' : ''}`} />
                    <span className="text-[9px] font-bold uppercase tracking-wider text-center">{t.label}</span>
                  </button>
                ))}
              </div>

              {/* Theme Preview GIF */}
              <div className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Background GIF</Label>
                  <div className="relative group">
                    <Button variant="outline" size="sm" className="h-8 rounded-none border-navy/20 text-[10px] uppercase font-bold tracking-wider">
                      <Camera className="w-3 h-3 mr-2" />
                      Upload Custom
                    </Button>
                    <input 
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, 3)}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="animate-in fade-in slide-in-from-top-2 duration-500">
                  <div className="relative aspect-video w-full overflow-hidden border border-soft-grey group bg-navy/5">
                    {customBg && (
                      <button 
                        onClick={() => setCustomBg('')}
                        className="absolute top-2 right-2 z-30 p-1.5 bg-navy text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                    <img 
                      src={customBg || THEME_GIFS[theme]} 
                      alt={`${theme} preview`} 
                      className="w-full h-full object-cover opacity-80"
                    />
                    <div className="absolute inset-0 bg-navy/20" />
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
                      <div className="text-[10px] tracking-[0.3em] font-bold text-white/60 mb-2 uppercase">Background Preview</div>
                      <div className="font-serif italic text-2xl md:text-3xl text-white tracking-widest uppercase drop-shadow-lg">
                        {occasion || theme}
                      </div>
                      <div className="w-12 h-0.5 bg-gold mt-4 shadow-[0_0_10px_rgba(212,175,55,0.8)]" />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[9px] text-navy/40 uppercase font-medium flex items-center justify-between">
                    <span>Or background URL:</span>
                    {isUploading[3] && <span className="text-gold animate-pulse">Uploading...</span>}
                  </div>
                  <Input 
                    placeholder="https://giph.com/media/..." 
                    value={customBg.startsWith('data:') ? '' : customBg}
                    onChange={(e) => setCustomBg(e.target.value)}
                    className="bg-warm-bg border-soft-grey focus:ring-gold rounded-none h-10 text-xs"
                  />
                </div>
              </div>
            </div>



            <div className="space-y-3">
              <Label className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Media (Photo or PDF)</Label>
              <div className="flex flex-col gap-2">
                <div className="relative group overflow-hidden border border-soft-grey bg-warm-bg aspect-video flex items-center justify-center">
                  {photo && !photoError ? (
                    <>
                      {photo.startsWith('data:application/pdf') ? (
                        <div className="flex flex-col items-center gap-2">
                          <FileText className="w-12 h-12 text-gold" />
                          <span className="text-[10px] font-bold text-navy/60 uppercase">PDF Loaded</span>
                        </div>
                      ) : (
                        <img 
                          src={photo} 
                          alt="Preview" 
                          className="w-full h-full object-cover" 
                          onError={() => setPhotoError(true)}
                        />
                      )}
                      <button 
                        onClick={() => {
                          setPhoto('');
                          setPhotoError(false);
                        }}
                        className="absolute top-2 right-2 p-1.5 bg-navy text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-navy/30">
                      {photoError ? (
                        <>
                          <Camera className="w-8 h-8 text-gold/50" />
                          <span className="text-[9px] font-bold uppercase text-gold/50">Load Error</span>
                        </>
                      ) : (
                        <>
                          <Upload className="w-8 h-8" />
                          <span className="text-[10px] font-bold uppercase">Upload File</span>
                        </>
                      )}
                    </div>
                  )}
                  <input 
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => handleFileUpload(e, 1)}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    title="Upload media"
                  />
                </div>
                <div className="text-[9px] text-navy/40 uppercase font-medium flex items-center justify-between">
                  <span>Or paste URL:</span>
                  {isUploading[1] && <span className="text-gold animate-pulse">Uploading...</span>}
                </div>
                <Input 
                  id="photo" 
                  placeholder="https://..." 
                  value={photo.startsWith('data:') ? '' : photo}
                  onChange={(e) => {
                    setPhoto(e.target.value);
                    setPhotoError(false);
                  }}
                  className="bg-warm-bg border-soft-grey focus:ring-gold rounded-none h-10 text-xs"
                />
              </div>
            </div>

            <div className="space-y-3">
              <Label htmlFor="message" className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Your Message</Label>
              <textarea
                id="message"
                rows={4}
                placeholder="Write something heartfelt..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-4 rounded-none bg-warm-bg border border-soft-grey focus:ring-2 focus:ring-gold focus:outline-none transition-all resize-none font-sans italic"
              />
            </div>

            <div className="space-y-3">
              <Label className="text-[10px] uppercase tracking-widest font-bold text-navy/40">Background Music</Label>
              <Select value={musicUrl} onValueChange={setMusicUrl}>
                <SelectTrigger className="bg-warm-bg border-soft-grey rounded-none h-12">
                  <SelectValue placeholder="Select music" />
                </SelectTrigger>
                <SelectContent>
                  {MUSIC_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      <div className="flex items-center gap-2">
                        <Music className="w-4 h-4 text-gold" />
                        {opt.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
          <CardFooter className="bg-warm-bg p-8 flex flex-col gap-6">
            <div className="flex flex-col sm:flex-row gap-4 w-full">
              <Button 
                onClick={handleGenerate}
                className="bg-navy text-white hover:bg-navy/90 flex-1 h-14 rounded-none text-lg font-bold tracking-tight shadow-xl"
              >
                Preview Mode
              </Button>
              <Button
                onClick={handleSaveToDatabase}
                disabled={isSaving}
                className="bg-gold text-white hover:bg-gold/90 flex-1 h-14 rounded-none text-lg font-bold tracking-tight shadow-xl"
              >
                {isSaving ? (
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                ) : (
                  <Save className="w-5 h-5 mr-2" />
                )}
                Save & Get Code
              </Button>
            </div>

            {/* Load by Code Section */}
            <div className="w-full pt-4 border-t border-navy/5">
              <div className="flex items-center gap-2 mb-3">
                <Key className="w-3 h-3 text-gold" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-navy/60">Have a wish code?</span>
              </div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="ENTER CODE (E.G. B7X2K9)"
                    value={loadCode}
                    onChange={(e) => setLoadCode(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === 'Enter' && handleLoadByCode()}
                    className="w-full bg-white border border-navy/10 h-10 px-4 text-xs font-bold tracking-widest focus:outline-none focus:ring-1 focus:ring-gold/30 placeholder:text-navy/20"
                  />
                  {isLoadingCode && (
                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                      <Loader2 className="w-3 h-3 animate-spin text-gold" />
                    </div>
                  )}
                </div>
                <Button
                  onClick={handleLoadByCode}
                  disabled={isLoadingCode || !loadCode}
                  className="bg-navy text-white hover:bg-navy/90 h-10 px-6 rounded-none text-[10px] font-bold tracking-widest uppercase"
                >
                  <Search className="w-3 h-3 mr-2" />
                  Load
                </Button>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 w-full">
              <Button
                variant="outline"
                className="border-navy text-navy hover:bg-navy hover:text-white flex-1 h-12 rounded-none text-sm font-bold tracking-tight"
                onClick={() => {
                  if (!recipient || !message) {
                    alert('Please fill in the recipient and message first!');
                    return;
                  }
                  
                  const data: any = { r: recipient, o: occasion, m: message, t: theme };
                  if (musicUrl) data.mu = musicUrl;
                  if (photo) data.p = photo;
                  if (photoTheme && photoTheme !== 'gold') data.pt = photoTheme;
                  if (messageTheme && messageTheme !== 'modern') data.mt = messageTheme;
                  if (customBg) data.cb = customBg;
                  
                  const payload = JSON.stringify(data);
                  const compressed = LZString.compressToEncodedURIComponent(payload);
                  
                  const shareUrl = `${window.location.origin}${window.location.pathname}?w=${compressed}`;
                  navigator.clipboard.writeText(shareUrl);
                  alert('Compressed link copied to clipboard!');
                }}
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy Mini Link (No Database)
              </Button>
            </div>
            <p className="text-[10px] text-navy/40 font-bold uppercase tracking-widest text-center">
              Create a moment that lasts forever. Database links are persistent.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
